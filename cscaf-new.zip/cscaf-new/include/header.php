﻿<nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom nv-setting">
	<div class="container-fluid">
		<button class="btn btn-primary sidebar-tgl" id="sidebarToggle"><span class="navbar-toggler-icon"></span></button>
		<!--
		<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
		-->
		<div class="collapse navbar-collapse" id="navbarSupportedContent">
			<ul class="navbar-nav ms-auto mt-2 mt-lg-0">
				<li class="nav-item active"><a class="nav-link" href="https://niua.org/c-cube/newsletter">NEWSLETTER</a></li>
				<li class="nav-item"><a class="nav-link" href="https://niua.org/c-cube/podcast">PODCAST</a></li>
				<li class="nav-item"><a class="nav-link" href="https://niua.org/c-cube/blogs">BLOG</a></li>
				<li class="nav-item"><a class="nav-link" href="https://niua.org/c-cube/contact">CONTACT</a></li>
				<li class="nav-item"><a class="nav-link" href="https://niua.org/c-cube/content/climate-centre-cities-c-cube">C-CUBE</a></li>
			</ul>
		</div>
	</div>
</nav>