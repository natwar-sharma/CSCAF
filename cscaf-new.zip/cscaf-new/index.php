﻿<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>CSCAF</title>
        <!-- Favicon-->
		<?php include'include/head.php'; ?>
        
    </head>
    <body>
        <div class="d-flex container" id="wrapper">
            <!-- Sidebar-->
           
			<?php include'include/sidebar.php'; ?>
            <!-- Page content wrapper-->
            <div id="page-content-wrapper">
                <!-- Top navigation-->
                <?php include'include/header.php'; ?>
                <!-- Page content-->
                <div class="container-fluid">
					<center>
                    <h1 class="mt-4 bclr">1. INTRODUCTION </h1>
                    <h3 class="gclr"> CLIMATE RISK PROFILE OF URBAN INDIA </h3>
					</center>
					<div class="row main-area" >
						<div class="">
							<img src="assets/images/intro-city1.svg" width="100%"></img>
						</div>
					</div>
				
                </div>
				
				<div class="container-fluid">
					<center>
                    <h3 class="gclr"> CITIES ARE GROWTH POWERHOUSES </h3>
					</center>
					<div class="row main-area" >
						<div class="col-sm-6">
							India has been one of the fastest growing economies in the world as per the World Economic Outlook in 2020 and 2021. Much of this growth has been driven by cities and towns. In 2011, India’s urban centres constituted approximately 31% of the total population, contributing to 63% of the national GDP, and are projected to accommodate close to 40% of the total population, contributing to 75% of the national GDP very soon. An analysis of urban GDP growth to 2035 found 17 out of 20 the fastest-growing cities in the world would be in India. As cities continue to fuel India’s economic growth and remain centres for development, they also face challenges with respect to physical infrastructure, institutions, health and environmental degradation. Studies indicate that poor planning and urban management are expected to cost Indian cities somewhere between $2.6 and $13 billion annually. 
						</div>
						<div class="col-sm-6">
							<img src="assets/images/cities-growth1.svg" class="home-img-setting"></img>
							<img src="assets/images/cities-growth2.svg" class="home-img-setting"></img>
						</div>
						
					</div>
				
                </div>
				
				<div><button type="button" class="dwn-btn"> Download This Chapter</button></div>
					
				<div class="container-fluid">
					<div class="row main-area pre-next" >
						<div class="col-sm-6 pre-btn"><a href="home.php">< PREVIOUS</a></div>
						<div class="col-sm-6 nxt-btn"><a href="cscaf.php">NEXT ></a></div>
					</div>
                </div>
            </div>
        </div>
        
		<?php include 'include/foot.php'; ?>
    </body>
</html>
