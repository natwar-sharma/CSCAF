﻿<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>CSCAF</title>
        <!-- Favicon-->
        <?php include'include/head.php'; ?>
    </head>
    <body>
        <div class="d-flex container" id="wrapper">
            <!-- Sidebar-->
            <?php include'include/sidebar.php'; ?>
            <!-- Page content wrapper-->
            <div id="page-content-wrapper">
                <!-- Top navigation-->
                 <?php include'include/header.php'; ?>
                <!-- Page content-->
                <div class="container-fluid">
					<center>
                    <h1 class="mt-4 bclr">7. WASTE MANAGEMENT</h1>
                    <h3 class="gclr"> CITYS' PERFORMANCE </h3>
					</center>
					<div class="row1 main-area1">
						<div class="row">
							<div class="col-sm-6">
								<img src="assets/images/1.png" class="urbn-img-1"></img>
							</div>
							<div class="col-sm-6">
								<img src="assets/images/waste-mgt2.svg" class="urbn-img-1"></img>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-12">
								<img src="assets/images/waste-mgt3.svg"></img>
							</div>
						</div>
					</div>
				
                </div>
				
				<div class="container-fluid">
					
					<center>
                    <h3 class="gclr egb-heading"> INSIGHT </h3>
					</center>
					
					<div class="row1 main-area1">
						<div class="row city-cls">
							<div class="col-sm-12">
								<img src="assets/images/waste-mgt-insight.svg" width="100%"></img>
							</div>
						</div>
					</div>
                </div>
				
				<div class="container-fluid">
					<center>
                    <h3 class="gclr mobility-hd"> ACTION IN CITIES </h3>
					</center>
					<div class="row1 main-area1">
						<div class="row">
							<div class="col-sm-2">
								<img src="assets/images/waste-mgt-ujjain.png" class="aic-imgmain"></img>
							</div>
							<div class="col-sm-4">
								<b class="bclr">Ujjain</b>
								<span class="aic-heading">Bio-methanation project</span>
								<p>The city has adopted an integrated approach to strategically process and reduce the bio-degradable waste of the city to generate electricity by a bio-methanation plant. This plant is helping in the solid waste management of the city and is also a step towards reducing the burden on non-renewable resources by producing electricity used in the nearby street lights. The slurry generated from bio-methanation is utilized for landscaping, gardening and farming purposes. The project has reduced greenhouse emissions into the environment by 12,176 Kg/month.</p> 
							</div>
							<div class="col-sm-2">
								<img src="assets/images/waste-mgt-ahemedabad.png" class="aic-imgmain"></img>
							</div>
							<div class="col-sm-4">
								<b class="bclr">Ahmedabad</b>
								<span class="aic-heading">Material Recovery Facility</span>
								<p>The Material Recovery Facility (MRF) at Ahmedabad runs on a public private partnership (PPP) model between Ahmedabad Municipal Corporation (AMC) and Nepra Resource Management Pvt. Ltd.  The daily sorting capacity of dry waste of the MRF plant is around 100 MT. Dry Waste is collected with the help of waste pickers and through collection vehicles and brought to the material recovery facility (MRF) where it is manually segregated, checked and segregated waste is then sold to the authorized recyclers.</p> 
							</div>
						</div>
						<div class="row">
							<div class="col-sm-2">
								<img src="assets/images/waste-mgt-delhi.png" class="aic-imgmain"></img>
							</div>
							<div class="col-sm-4">
								<b class="bclr">Delhi</b>
								<span class="aic-heading">Construction and Demolition Waste recycling facility at Burari</span>
								<p>North Delhi Municipal Corporation has installed a recycling facility in Burari which is installed, operated and maintained on a Public Private Partnership (PPP) basis between the Corporation and Infrastructure Leasing and Financial Services Limited (IL&FS) Environment. There are 168 designated intermediate collection points across the city from which waste is transported to the processing facility.</p> 
							</div>
							<div class="col-sm-2">
								<img src="assets/images/waste-mgt-coimbatore.png" class="aic-imgmain"></img>
							</div>
							<div class="col-sm-4">
								<b class="bclr">Coimbatore</b>
								<span class="aic-heading">Biogas plant and Vermicomposting plant in Coimbatore - Processing and treating wet waste</span>
								<p>The Coimbatore city municipal corporation has installed a biogas plant at Amma Unavagam premises at Chitra Nagar. Vegetable waste, cooked and uncooked food waste from the hotels and restaurants in and around the are used to generate biogas through anaerobic digestion. At the vermicomposting plant, segregated waste is processed and converted into compost at this site.</p> 
							</div>
						</div>
						<div class="row">
							<div class="col-sm-2">
								<img src="assets/images/waste-mgt-jabalpur.png" class="aic-imgmain"></img>
							</div>
							<div class="col-sm-4">
								<b class="bclr">Jabalpur</b>
								<span class="aic-heading">Zero landfill & bin free city</span>
								<p>The city has adopted a  robust solid waste management solution which aims to integrate Waste-to-Energy plant with the centralized monitoring system with a better governance on collection of daily garbage, monitoring of garbage collection, transportation system by the command control center, while ensuring cost reduction and resource optimization.</p> 
							</div>
							<div class="col-sm-2">
								<img src="assets/images/waste-mgt-indore.png" class="aic-imgmain"></img>
							</div>
							<div class="col-sm-4">
								<b class="bclr">Indore</b>
								<span class="aic-heading">Bioremediation/ Bio-mining of legacy waste</span>
								<p>Indore had taken considerable steps to tackle waste management in new and innovative ways. One such example is Indore’s Devguradiya dumpsite where the dumping yard is saddled by heaps of garbage for decades. The project aims to clear legacy waste dumps and reclaim 100 acre land worth Rs. 300 Cr. Due to adoption of a scientific bio-remediation process the area inside the processing and disposal site is transformed into a beautiful green-belt uplifting the environment, eliminating dump fires, reducing emissions, soil pollution and groundwater contamination.</p> 
							</div>
						</div>
					</div>
                </div>
				
				<div class="container-fluid">
					<center>
                     <div class="wf-icon"><img src="assets/images/waste-mgt-bottom1.svg"></img><h3 class="gclr-wf"> WAY FORWARD </h3></div>
					</center>
					<div class="row1 main-area1">
						<div class="row">
							<div class="col-sm-4">
								<img src="assets/images/waste-mgt-bottom2.svg"></img>
							</div>
							<div class="col-sm-4">
								<img src="assets/images/waste-mgt-bottom3.svg"></img>
							</div>
							<div class="col-sm-4">
								<img src="assets/images/waste-mgt-bottom4.svg"></img>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-4">
								<span class="aic-heading">Enhancing waste segregation</span>
								<p>Cities can focus on promoting source segregation of dry and wet waste through various incentive based awareness programs and rigorous campaigning to achieve 100% recycling and reuse of waste. Citizens can be encouraged to adopt home or neighbourhood composting. Besides, following guidelines from the advisory on Material Recovery Facility (MRF) can help cities to strengthen their plastic waste management.</p> 
							</div>
							<div class="col-sm-4">
								<span class="aic-heading">Strengthening Construction and Demolition (C&D) waste management</span>
								<p>It is important for cities to build a robust C&D waste management system. This includes maintaining inventories of construction activities in the city, notifying dumping points, expanding storage facilities for C&D waste, establishing a collection mechanism, enforcing user charges & penalty for non-compliance etc. ULBs themselves or in association with the private sector can initiate some of these measures.</p> 
							</div>
							<div class="col-sm-4">
								<span class="aic-heading">Scientific management of landfills </span>
								<p>Cities are encouraged to make efforts to scientifically manage and close engineered landfills and dumpsites in order to avoid significant GHG emissions. Innovative and sustainable landfill remediation methods like biomining and bioremediation can be promoted over the traditional ‘capping’ which means covering the landfill with a layer of soil.</p> 
							</div>
						</div>
						
					</div>
                </div>
				
				<div><button type="button" class="dwn-btn"> Download this Chapter</button></div>
				<div class="container-fluid">
					<div class="row main-area pre-next" >
						<div class="col-sm-6 pre-btn"><a href="water-management.php">< PREVIOUS</a></div>
						<div class="col-sm-6 nxt-btn"><a href="climate-centre-city.php">NEXT ></a></div>
					</div>
                </div>
            </div>
        </div>
        <!-- Bootstrap core JS-->
         <?php include 'include/foot.php'; ?>
    </body>
</html>
