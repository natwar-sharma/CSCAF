﻿<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>CSCAF</title>
        <!-- Favicon-->
       <?php include'include/head.php'; ?>
    </head>
    <body>
        <div class="d-flex container" id="wrapper">
            <!-- Sidebar-->
           <?php include'include/sidebar.php'; ?>
            <!-- Page content wrapper-->
            <div id="page-content-wrapper">
                <!-- Top navigation-->
               <?php include'include/header.php'; ?>
                <!-- Page content-->
                <div class="container-fluid">
					<center>
                    <h1 class="mt-4 bclr">8. CLIMATE CENTER FOR CITIES MANAGEMENT</h1>
                    <h3 class="gclr"> BULDING CLIMATE ACTIONS </h3>
					</center>
					<div class="row1 main-area1">
						<div class="row">
							<div class="col-sm-12">
								For mainstreaming climate actions, detailed understanding of climate related risks emerging from hydro-meteorological hazards and vulnerabilities is required. While city administrations are actively focussing on development to cater to the growing urban population, they sometimes lack the capacity or ability to undertake relevant climate measures. Being at the crossroads of urban transformation cities have an unique opportunity to cater to sustainable and resilient development. With this intent, the Climate Centre for Cities is in the process of undertaking several initiatives to help build conceptual, technical, administrative and innovation capacities across key areas of ULBs.
							</div>
						</div>
					</div>
                </div>
				
				<div class="container-fluid">
					<div class="row1 main-area1">
						<div class="row">
							<div class="col-sm-12">
								<img src="assets/images/climate-centre1.svg" class="ccc-img"></img>
							</div>
						</div>
					</div>
                </div>
				
				
				<div class="container-fluid">
					<center>
                    <h3 class="gclr mobility-hd"> CLIMATESMART CITIES ALLIANCE</h3>
					</center>
					<div class="row1 main-area1">
						<div class="row">
							<div class="col-sm-12">
								<img src="assets/images/climate-centre2.png" class="ccc-img"></img>
							</div>
						</div>
					</div>
                </div>
				
				<div><button type="button" class="dwn-btn"> Download this Chapter</button></div>
				<div class="container-fluid">
					<div class="row main-area pre-next" >
						<div class="col-sm-6 pre-btn"><a href="waste-management.php">< PREVIOUS</a></div>
						
					</div>
                </div>
            </div>
        </div>
        <!-- Bootstrap core JS-->
         <?php include 'include/foot.php'; ?>
    </body>
</html>
