﻿	<div class="border-end bg-white" id="sidebar-wrapper">
		<div class="sidebar-heading border-bottom bg-light side-bar-setting"><img src="assets/images/C3_Logo.png" style="width: 115px; text-align: center; padding: 5px; margin: 3px;"></img> <span class="nav-item">| E-report</span></div>
		<div class="list-group list-group-flush">
			<!--<a class="list-group-item list-group-item-action list-group-item-light p-3" href="">Home</a>-->
			<a class="list-group-item list-group-item-action list-group-item-light p-3" href=""><button type="button" class="dwn-full-btn">Download Full Report</button></a>
			<a class="list-group-item list-group-item-action list-group-item-light p-3" href="index.php">Introduction</a>
			<a class="list-group-item list-group-item-action list-group-item-light p-3" href="cscaf.php">CSCAF 2.0</a>
			<a class="list-group-item list-group-item-action list-group-item-light p-3" href="urban-planning.php">Urban Planning, Green Cover & Biodiversity</a>
			<a class="list-group-item list-group-item-action list-group-item-light p-3" href="energy-green-building.php">Energy & Green Building</a>
			<a class="list-group-item list-group-item-action list-group-item-light p-3" href="mobility-air-quality.php">Mobility & Air Quality</a>
			<a class="list-group-item list-group-item-action list-group-item-light p-3" href="water-management.php">Water Management</a>
			<a class="list-group-item list-group-item-action list-group-item-light p-3" href="waste-management.php">Waste Management</a>
			<a class="list-group-item list-group-item-action list-group-item-light p-3" href="climate-centre-city.php">Climate Center for Cities</a>
		</div>
	</div>