﻿<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>CSCAF</title>
        <!-- Favicon-->
         <?php include'include/head.php'; ?>
    </head>
    <body>
        <div class="d-flex container" id="wrapper">
            <!-- Sidebar-->
            <?php include'include/sidebar.php'; ?>
            <!-- Page content wrapper-->
            <div id="page-content-wrapper">
                <!-- Top navigation-->
               <?php include'include/header.php'; ?>
                <!-- Page content-->
                <div class="container-fluid">
					<center>
                    <h1 class="mt-4 bclr">4. ENERGY AND GREEN BUILDINGS</h1>
                    <h3 class="gclr"> CITYS' PERFORMANCE </h3>
					</center>
					<div class="row1 main-area1" >
					
						<div class="row">
							<div class="col-sm-6">
								<img src="assets/images/1.png" class="urbn-img-1"></img>
							</div>
							<div class="col-sm-6">
								<img src="assets/images/energy2.svg" class="urbn-img-1"></img>
							</div>

						</div>
						<div class="row">
							<div class="col-sm-12">
								<img src="assets/images/energy3.svg"></img>
							</div>
						</div>
					</div>
				
                </div>
				
				<div class="container-fluid">
					
					<center>
                    <h3 class="gclr egb-heading"> INSIGHT </h3>
					</center>
					
					<div class="row1 main-area1">
						<div class="row city-cls">
							<div class="col-sm-12">
								<img src="assets/images/energy-insight.svg" width="100%"></img>
							</div>
						</div>
					</div>
                </div>
				
				<div class="container-fluid">
					<center>
                    <h3 class="gclr"> ACTION IN CITIES </h3>
					</center>
					<div class="row1 main-area1">
						<div class="row">
							<div class="col-sm-2">
								<img src="assets/images/energy-tirupati.png" class="aic-imgmain"></img>
							</div>
							<div class="col-sm-4">
								<b class="bclr">Tirupati</b>
								<span class="aic-heading">Solar Energy Generation through efficient usage of land, water and rooftop surface</span>
								<p>To contribute towards national goals of GHG reduction, Tirupati has undertaken a giant leap towards renewable sources of energy through “11 MW Solar Power projects”. The projects include rooftop solar installations and land based solar park along with an innovative floating solar park at Kailashgiri Reservoir.</p> 
							</div>
							<div class="col-sm-2">
								<img src="assets/images/energy-pimpri.png" class="aic-imgmain"></img>
							</div>
							<div class="col-sm-4">
								<b class="bclr">Pimpri-Chinchwad</b>
								<span class="aic-heading">GRIHA rated development authority building</span>
								<p>The Pimpri Chinchwad municipal corporation has adopted GRIHA, the national rating system for green buildings in India, with the objective of promoting sustainable development and wise use of natural resources. Incentives like discounted premiums for developers and reduced property tax for homeowners have been implemented to promote adoption of green buildings. The Pimpri Chinchwad Navnagar Development Authority building designed in 2008 is also a certified green building which is naturally ventilated and runs on solar energy.</p> 
							</div>
						</div>
						<div class="row">
							<div class="col-sm-2">
								<img src="assets/images/energy-nagpur.png" class="aic-imgmain"></img>
							</div>
							<div class="col-sm-4">
								<b class="bclr">Nagpur</b>
								<span class="aic-heading">Project green light</span>
								<p>Nagpur has initiated retrofitting the existing conventional street lighting system with LED lights that has resulted in energy savings of more than 40% of electricity annually and has led to reduction in carbon footprints. It is one of the largest environmentally friendly LED (Light Emitting Diode) lights projects ever undertaken by a city with an aim to replace 1,36,000 streetlights.</p> 
							</div>
						</div>
						
					</div>
                </div>
				
				<div class="container-fluid">
					<center>
                     <div class="wf-icon"><img src="assets/images/energy-bottom1.svg"></img><h3 class="gclr-wf"> WAY FORWARD </h3></div>
					</center>
					<div class="row1 main-area1">
						<div class="row">
							<div class="col-sm-4">
								<img src="assets/images/energy-bottom2.svg"></img>
							</div>
							<div class="col-sm-4">
								<img src="assets/images/energy-bottom3.svg"></img>
							</div>
							<div class="col-sm-4">
								<img src="assets/images/energy-bottom4.svg"></img>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-4">
								<span class="aic-heading">Leveraging government programmes and schemes to enhance energy efficiency in cities</span>
								<p>Cities can leverage government schemes and initiatives like the Rooftop Solar programme, Solar Net Metering and Grid Connected Wind-Solar Hybrid Power Projects for adopting renewable energy at city level. Cities may coordinate with local power distribution companies (DISCOMs), state energy distribution agency (SEDA), and State Electricity Regulatory Commission (SERC) to adopt the schemes. A monitoring and evaluation cell can be established to work with the Energy Service Company (ESCO) for facilitating energy efficient projects and conducting audits as part of Bureau of Energy Efficiency’s Municipal Demand Side Management Program.</p> 
							</div>
							<div class="col-sm-4">
								<span class="aic-heading">Integrating systems with ICCCs to monitor energy efficiency</span>
								<p>Cities that have ICCCs can integrate an Energy Monitoring Information System (EMIS) integrated with the ICCCs to monitor sector wise energy usage. Smart automation through GIS based monitoring integrated with the ICCCs can also bring in further efficiency in street light management. Suitable PPP/ESCO models of financing may be used for such implementation.</p> 
							</div>
							<div class="col-sm-4">
								<span class="aic-heading">Data informed decision making </span>
								<p>Spatial mapping and analysis are crucial for assessing gaps and guiding policy making and planning for blue-green planning, biodiversity management and disaster resilience. Cities are recommended to prepare and update GIS maps for attributes like water bodies and open spaces coverage, encroachments, urban heat island, disaster specific risks and vulnerabilities, tree type and biodiversity, etc.</p> 
							</div>
						</div>
						
					</div>
                </div>
				
				<div><button type="button" class="dwn-btn"> Download this Chapter</button></div>
				<div class="container-fluid">
					<div class="row main-area pre-next" >
						<div class="col-sm-6 pre-btn"><a href="urban-planning.php">< PREVIOUS</a></div>
						<div class="col-sm-6 nxt-btn"><a href="mobility-air-quality.php">NEXT ></a></div>
					</div>
                </div>
            </div>
        </div>
        <!-- Bootstrap core JS-->
        <?php include 'include/foot.php'; ?>
    </body>
</html>
