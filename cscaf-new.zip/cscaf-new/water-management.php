﻿<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>CSCAF</title>
        <!-- Favicon-->
       <?php include'include/head.php'; ?>
    </head>
    <body>
        <div class="d-flex container" id="wrapper">
            <!-- Sidebar-->
            <?php include'include/sidebar.php'; ?>
            <!-- Page content wrapper-->
            <div id="page-content-wrapper">
                <!-- Top navigation-->
               <?php include'include/header.php'; ?>
                <!-- Page content-->
                <div class="container-fluid">
					<center>
                    <h1 class="mt-4 bclr">6. WATER MANAGEMENT</h1>
                    <h3 class="gclr"> CITYS' PERFORMANCE </h3>
					</center>
					<div class="row1 main-area1" >
					
						<div class="row">
							<div class="col-sm-6">
								<img src="assets/images/1.png" class="urbn-img-1"></img>
							</div>
							<div class="col-sm-6">
								<img src="assets/images/water-mgt2.svg" class="urbn-img-1"></img>
							</div>

						</div>
						<div class="row">
							<div class="col-sm-12">
								<img src="assets/images/water-mgt3.svg"></img>
							</div>
						</div>
					</div>
                </div>
				
				<div class="container-fluid">
					
					<center>
                    <h3 class="gclr egb-heading"> INSIGHT </h3>
					</center>
					<div class="row1 main-area1">
						<div class="row city-cls" >
							<div class="col-sm-12">
								<img src="assets/images/water-mgt-insight.svg" width="100%"></img>
							</div>
						</div>
					</div>
                </div>
				
				<div class="container-fluid">
					<center>
                    <h3 class="gclr mobility-hd"> ACTION IN CITIES </h3>
					</center>
					<div class="row1 main-area1">
						<div class="row">
							<div class="col-sm-2">
								<img src="assets/images/water-mgt-namchi.png" class="aic-imgmain"></img>
							</div>
							<div class="col-sm-4">
								<b class="bclr">Namchi</b>
								<span class="aic-heading">Integrated water supply management, augmentation of existing distribution network & strategy for water conservation & reuse</span>
								<p>Namchi has implemented a strategy for water conservation & reuse using co-polymer based rain water harvesting technology. The city aids towards the greater objective of water management and conservation and to increase recharge of groundwater by capturing and storing rainwater. Rainwater harvesting from rooftop run-offs and natural water bodies augment the community development.</p> 
							</div>
							<div class="col-sm-2">
								<img src="assets/images/water-mgt-bhubaneshwar.png" class="aic-imgmain"></img>
							</div>
							<div class="col-sm-4">
								<b class="bclr">Bhubaneshwar</b>
								<span class="aic-heading">Assessment and implementation for NRW reduction</span>
								<p>The city has planned to expand the network to achieve universal coverage by providing every household with water supply service connection. One of the key municipal reforms under AMRUT programme, is to reduce NRW from current levels to 20% providing the following benefits: Ensuring equitable water supply and reduce demand/supply gap; Improvement in network efficiency by reducing water losses; Improvement in water supply coverage, reliability and quality of service; Improving cost recovery from water supply operations.</p> 
							</div>
						</div>
						<div class="row">
							<div class="col-sm-2">
								<img src="assets/images/water-mgt-surat.png" class="aic-imgmain"></img>
							</div>
							<div class="col-sm-4">
								<b class="bclr">Surat</b>
								<span class="aic-heading">Reuse & Recycle of Treated Wastewater Action Plan 2019</span>
								<p>The city of Surat has prepared an action plan which promotes the reuse of treated sewage for different purposes of gardening, industrial reuse, tanker filling, lake restoration, flushing and construction with a vision to maximize the collection & treatment of generated sewage and reuse of treated wastewater on a sustainable basis, thereby reducing dependency on freshwater resources. Also, the reuse of treated wastewater can become a source for revenue generation.</p>
							</div>
							<div class="col-sm-2">
								<img src="assets/images/water-mgt-pune.png" class="aic-imgmain"></img>
							</div>
							<div class="col-sm-4">
								<b class="bclr">Pune</b>
								<span class="aic-heading">Standard Operation Procedure for Flood Control (SOP) </span>
								<p>The city of Pune has prepared a SOP for taking timely action, systematic coordination among department and public, streamlining communication and decision making. The core objectives include identifying hazard potential downstream of the dam, warning about probable floods in advance, taking preventive actions in advance, monitoring flood situation, protection of human lives & infrastructure, and restoring damaged infrastructure due to floods.</p> 
							</div>
						</div>
						<div class="row">
							<div class="col-sm-2">
								<img src="assets/images/water-mgt-durgapur.png" class="aic-imgmain"></img>
							</div>
							<div class="col-sm-4">
								<b class="bclr">Durgapur</b>
								<span class="aic-heading">Investment grade energy audit report</span>
								<p>The city has conducted an energy audit of the water supply system to carry out a performance evaluation of pump sets. Based on the energy audit, the pump and pump set efficiencies for all the pumping stations have been estimated. Along with estimation of efficiency of pump sets, performance indicators such as specific energy consumption were also evaluated for the city. The energy saving has been calculated on the basis of energy audit activity conducted, where the estimated energy saving has a potential of 32%.</p> 
							</div>
							<div class="col-sm-2">
								<img src="assets/images/water-mgt-saharanpur.png" class="aic-imgmain"></img>
							</div>
							<div class="col-sm-4">
								<b class="bclr">Saharanpur</b>
								<span class="aic-heading">Investment grade energy audit</span>
								<p>The city has conducted an energy audit of the waste water management system to carry out a performance evaluation of pump sets. Based on the energy audit, the overall pump efficiencies for each running pump of borewells, sewage treatment plant and sewage pumping station have been estimated. Along with estimation of efficiency of pump sets specific energy consumption was also evaluated for pump. The energy saving calculated on the basis of energy audit estimates an energy saving potential of 48%.</p> 
							</div>
						</div>
					</div>
                </div>
				
				<div class="container-fluid">
					<center>
                     <div class="wf-icon"><img src="assets/images/water-mgt-bottom1.svg"></img><h3 class="gclr-wf"> WAY FORWARD </h3></div>
					</center>
					<div class="row1 main-area1">
						<div class="row">
							<div class="col-sm-4">
								<img src="assets/images/water-mgt-bottom2.svg"></img>
							</div>
							<div class="col-sm-4">
								<img src="assets/images/water-mgt-bottom3.svg"></img>
							</div>
							<div class="col-sm-4">
								<img src="assets/images/water-mgt-bottom4.svg"></img>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-4">
								<span class="aic-heading">Initiate water demand management plan</span>
								<p>Cities are recommended to initiate a water demand management plan to inform utilization of water resources keeping in mind the current and projected demand. This can provide direction towards adopting measures for rejuvenating water resources and replenishing groundwater. As a first step, cities can establish a water resource management committee to guide the process of conducting city wide water management plans.</p> 
							</div>
							<div class="col-sm-4">
								<span class="aic-heading">Measures to mitigate floods and water stagnation</span>
								<p>As a first step, cities can conduct assessments to identify vulnerable hotspots and adopt relevant structural and non-structural strategies to reduce the impact of floods and water stagnation. This includes measures such as preparing a storm-water management plan in alignment with the flood management plan to channel flood water efficiently and establishing SOPs for flood management. Further, initiating the implementation of an end-to-end Early Warning Systems (EWS) can greatly support cities in better preparing for floods.</p> 
							</div>
							<div class="col-sm-4">
								<span class="aic-heading">Studies to inform water and energy efficiency</span>
								<p>Studies such as non-revenue water study and energy audits can provide valuable information on water losses and energy consumed in water supply system and waste water management systems respectively. These studies can support in identifying gaps and can guide measures to reduce water losses and enhance energy efficiency in water supply and waste water management.</p> 
							</div>
						</div>
						
					</div>
                </div>
				
				<div><button type="button" class="dwn-btn"> Download this Chapter</button></div>
				<div class="container-fluid">
					<div class="row main-area pre-next" >
						<div class="col-sm-6 pre-btn"><a href="mobility-air-quality.php">< PREVIOUS</a></div>
						<div class="col-sm-6 nxt-btn"><a href="waste-management.php">NEXT ></a></div>
					</div>
                </div>
            </div>
        </div>
        <!-- Bootstrap core JS-->
         <?php include 'include/foot.php'; ?>
    </body>
</html>
