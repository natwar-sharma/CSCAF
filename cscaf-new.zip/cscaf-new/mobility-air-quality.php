﻿<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>CSCAF</title>
        <!-- Favicon-->
        <?php include'include/head.php'; ?>
    </head>
    <body>
        <div class="d-flex container" id="wrapper">
            <!-- Sidebar-->
             <?php include'include/sidebar.php'; ?>
            <!-- Page content wrapper-->
            <div id="page-content-wrapper">
                <!-- Top navigation-->
               <?php include'include/header.php'; ?>
                <!-- Page content-->
                <div class="container-fluid">
					<center>
                    <h1 class="mt-4 bclr">5. MOBILIY AND AIR QUALITY</h1>
                    <h3 class="gclr"> CITYS' PERFORMANCE </h3>
					</center>
					<div class="row1 main-area1" >
						<div class="row">
							<div class="col-sm-6">
								<img src="assets/images/1.png" class="urbn-img-1"></img>
							</div>
							<div class="col-sm-6">
								<img src="assets/images/mobility2.svg" class="urbn-img-1"></img>
							</div>

						</div>
						<div class="row">
							<div class="col-sm-12">
								<img src="assets/images/mobility3.svg"></img>
							</div>
						</div>
						
					</div>
				
                </div>
				
				<div class="container-fluid">
					
					<center>
                    <h3 class="gclr egb-heading"> INSIGHT </h3>
					</center>
					
					<div class="row1 main-area1">
						<div class="row city-cls">
							<div class="col-sm-12">
								<img src="assets/images/mobility-insight.svg" width="100%"></img>
							</div>
						</div>
					</div>
                </div>
				
				<div class="container-fluid">
					<center>
                    <h3 class="gclr mobility-hd"> ACTION IN CITIES </h3>
					</center>
					<div class="row1 main-area1">
						<div class="row">
							<div class="col-sm-2">
								<img src="assets/images/mobility-delhi.png" class="aic-imgmain"></img>
							</div>
							<div class="col-sm-4">
								<b class="bclr">Delhi</b>
								<span class="aic-heading">Electric Vehicle Policy</span>
								<p>Delhi Electric Vehicle Policy launched in 2020 has a vision to make Delhi the EV Capital of India. The Policy aims to achieve the overarching objective to improve Delhi’s air quality and create an entire supply-chain ecosystem for this new segment of vehicles. In order to significantly benefit Delhi’s air quality, the policy intends to deploy 25% of all new vehicles to be battery-operated vehicles by 2024.</p> 
							</div>
							<div class="col-sm-2">
								<img src="assets/images/mobility-naya-raipur.png" class="aic-imgmain"></img>
							</div>
							<div class="col-sm-4">
								<b class="bclr">Naya Raipur</b>
								<span class="aic-heading">BRTS public transport </span>
								<p>Naya Raipur has initiated a Bus Rapid Transit service for a seamless connectivity with Raipur and within the city of Atal Nagar. “Intelligent Tracking System” is being used for managing the bus system.</p> 
							</div>
						</div>
						<div class="row">
							<div class="col-sm-2">
								<img src="assets/images/mobility-chennai.png" class="aic-imgmain"></img>
							</div>
							<div class="col-sm-4">
								<b class="bclr">Chennai</b>
								<span class="aic-heading">Streets for People</span>
								<p>Chennai is one of the first cities in India to adopt a NMT Policy in 2014. Since then it has implemented a host of initiatives prioritising pedestrians, cyclists and public transport users. The ‘Streets for People’ initiative has been instrumental in transforming more than 100 km of the city’s streets through adoption of complete street guidelines, segregation of vehicular and pedestrian traffic, creation of pedestrian plazas, introduction of public bike sharing services and better management of on-street parking.</p> 
							</div>
							<div class="col-sm-2">
								<img src="assets/images/mobility-coimbatore.png" class="aic-imgmain"></img>
							</div>
							<div class="col-sm-4">
								<b class="bclr">Coimbatore</b>
								<span class="aic-heading">City wide Cycling and Pedestrian Network Plan</span>
								<p>Coimbatore has recently prepared a city wide cycling and pedestrian network plan which was approved in January 2020. The plan sets out  a comprehensive approach for building a network of cycling and pedestrian routes in the city and sets forth a comprehensive set of measures which would put the city on a path of achieving sustainable transport goals. The plan has an implementation period of 15 years.</p> 
							</div>
						</div>
						<div class="row">
							<div class="col-sm-2">
								<img src="assets/images/mobility-agra.png" class="aic-imgmain"></img>
							</div>
							<div class="col-sm-4">
								<b class="bclr">Agra</b>
								<span class="aic-heading">Air Quality Monitoring enhanced through ICCC</span>
								<p>Agra city has deployed 39 Polludrone sensors across the city to monitor ambient air quality It assesses all the critical pollutants present in the air - PM2.5, PM10, CO2, CO, SO2, NO, NO2, and O3, along with the weather parameters - noise, light, UV radiation, temperature, humidity, and rainfall. The dashboard of the system has been integrated with the city’s Command and Control Centre. Real-time pollution data can be observed here, which can assist in mitigating the root cause and create awareness among local people and tourists about the current environmental health.</p> 
							</div>
							<div class="col-sm-2">
								<img src="assets/images/mobility-dehradun.png" class="aic-imgmain"></img>
							</div>
							<div class="col-sm-4">
								<b class="bclr">Dehradun</b>
								<span class="aic-heading">Clean Air Action Plan</span>
								<p>Dehradun has prepared the Clean Air Action Plan (2018-22) with the aim to meet the prescribed annual average ambient air quality standards. The Plan includes a city specific need assessment, a detailed GHG inventory and a proposed action plan.</p> 
							</div>
						</div>
					</div>
                </div>
				
				<div class="container-fluid">
					<center>
                     <div class="wf-icon"><img src="assets/images/mobility-bottom1.svg"></img><h3 class="gclr-wf"> WAY FORWARD </h3></div>
					</center>
					<div class="row1 main-area1">
						<div class="row">
							<div class="col-sm-4">
								<img src="assets/images/mobility-bottom2.svg"></img>
							</div>
							<div class="col-sm-4">
								<img src="assets/images/mobility-bottom3.svg"></img>
							</div>
							<div class="col-sm-4">
								<img src="assets/images/mobility-bottom4.svg"></img>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-4">
								<span class="aic-heading">Enhancing low carbon public transport for reducing GHG emissions and improving air quality</span>
								<p>Cities can conduct public transport demand assessments and explore PPP models for increasing fleet size of buses. Cities can improve efficiency, route rationalization, schedules and last mile connectivity to attract people to shift to public transport. Leveraging the FAME-II scheme and adopting Niti Ayog’s guidelines on shared mobility for procuring low carbon vehicles (like E-rickshaws and E-Taxis) cities can procure low carbon vehicles and develop desired infrastructure to enable low carbon mobility transition.</p> 
							</div>
							<div class="col-sm-4">
								<span class="aic-heading">Increasing NMT coverage</span>
								<p>Many cities have initiated various projects on public bicycle sharing, awareness campaigns and to improve NMT infrastructure. Moving forward, cities can aim to increase the NMT coverage for cycle lanes and footpaths to over 35%, especially in high traffic clusters and high-use networks through dedicated planning and budget allocation.</p> 
							</div>
							<div class="col-sm-4">
								<span class="aic-heading">Monitoring air quality sensors and adopting NCAP</span>
								<p>Cities are recommended to install continuous air quality monitoring sensors and make the dynamic data available to the public through display boards and public applications like SAFAR/SAMEER. It is important to calibrate the installed sensors in consultation with the Central and State Pollution Control Boards to ensure the quality of data captured. Further, cities can develop city clean air action plans aligning to the National Clean Air Plan (NCAP) and initiate some of the actions to improve air quality and achieve the national air quality standards.</p> 
							</div>
						</div>
						
					</div>
                </div>
				
				<div><button type="button" class="dwn-btn"> Download this Chapter</button></div>
				<div class="container-fluid">
					<div class="row main-area pre-next" >
						<div class="col-sm-6 pre-btn"><a href="energy-green-building.php">< PREVIOUS</a></div>
						<div class="col-sm-6 nxt-btn"><a href="water-management.php">NEXT ></a></div>
					</div>
                </div>
            </div>
        </div>
        <!-- Bootstrap core JS-->
        <?php include 'include/foot.php'; ?>
    </body>
</html>
