﻿<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>CSCAF</title>
        <!-- Favicon-->
        <?php include'include/head.php'; ?>
    </head>
    <body>
        <div class="d-flex container" id="wrapper">
            <!-- Sidebar-->
             <?php include'include/sidebar.php'; ?>
            <!-- Page content wrapper-->
            <div id="page-content-wrapper">
                <!-- Top navigation-->
               <?php include'include/header.php'; ?>
                <!-- Page content-->
                <div class="container-fluid">
					<center>
                    <h1 class="mt-4 bclr">3. URBAN PLANNING, GREEN COVER & BIODIVERSITY</h1>
                    <h3 class="gclr"> CITYS' PERFORMANCE </h3>
					</center>
					<div class="row1 main-area1" >
					
						<div class="row">
							<div class="col-sm-6">
								<img src="assets/images/1.png" class="urbn-img-1"></img>
							</div>
							<div class="col-sm-6">
								<img src="assets/images/urban-planing-2.svg" class="urbn-img-1"></img>
							</div>

						</div>
						<div class="row">
							<div class="col-sm-12">
								<img src="assets/images/urban-planing-2a.svg"></img>
							</div>
						</div>
					</div>
				
                </div>
				
				<div class="container-fluid">
					<!--
					<center>
                    <h3 class="gclr"> INSIGHT </h3>
					</center>
					-->
					<div class="row1 main-area1">
						<div class="row city-cls">
							<div class="col-sm-12">
								<img src="assets/images/urban-planing-3.svg" width="100%"></img>
							</div>
						</div>
					</div>
				
                </div>
				
				<div class="container-fluid">
					<center>
                    <h3 class="gclr"> ACTION IN CITIES </h3>
					</center>
					<div class="row1 main-area1">
						<div class="row">
							<div class="col-sm-2">
								<img src="assets/images/urban-planing-vijay.svg" class="aic-imgmain"></img>
							</div>
							<div class="col-sm-4">
								<b class="bclr">Vijayawada</b>
								<span class="aic-heading">Greenery Development on Vijayawada Hills</span>
								<p>Vijayawada has prepared a strategy for converting a dumpsite into Model Park at Ajith Singh Nagar and allocated Rs.2.37 crores for the same. The city has prepared a detailed project report for Greenery Development on Vijayawada Hills with the objective of conserving all open spaces and hillocks within the city.</p> 
							</div>
							<div class="col-sm-2">
								<img src="assets/images/urban-planing-agra.svg" class="aic-imgmain"></img>
							</div>
							<div class="col-sm-4">
								<b class="bclr">Agra</b>
								<span class="aic-heading">Action Plan to increase Green Cover</span>
								<p>The city of Agra has prepared an action plan to increase green cover in the city by 15%. The action plan includes current status of green cover and assessment of the master plan of the city to devise long term strategies for increasing green cover.</p>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-2">
								<img src="assets/images/urban-planing-gangtok.svg" class="aic-imgmain"></img>
							</div>
							<div class="col-sm-4">
								<b class="bclr">Gangtok</b>
								<span class="aic-heading">Local Biodiversity Strategy and Action Plan (LBSAP)</span>
								<p>The LBSAP of Gangtok sets out a framework and a plan of action for conservation and sustainable use of biological diversity and equitable sharing of benefits derived from this use. The city has defined its LBSAP vision as ‘a prosperous Gangtok with focus on climate-smart development while ensuring the conservation of its cultural and ecological heritage’.</p> 
							</div>
							<div class="col-sm-2">
								<img src="assets/images/urban-planing-simla.svg" class="aic-imgmain"></img>
							</div>
							<div class="col-sm-4">
								<b class="bclr">Shimla</b>
								<span class="aic-heading">Multi-Hazard Risk and Vulnerability Assessment (HRVA)</span>
								<p>Shimla has conducted a Hazard, Risk and Vulnerability Analysis (HRVA) and developed a city level Risk Atlas to help stakeholders make risk-based choices to address vulnerabilities, mitigate hazards and prepare for response to and recovery from hazard events.</p> 
							</div>
						</div>
						<div class="row">
							<div class="col-sm-2">
								<img src="assets/images/urban-planing-chennai.svg" class="aic-imgmain"></img>
							</div>
							<div class="col-sm-4">
								<b class="bclr">Chennai</b>
								<span class="aic-heading">City Disaster Management Plan</span>
								<p>The Greater Chennai Corporation had prepared the first city disaster management plan as prescribed in the NDMA guidelines. The CDMP has taken into account the vulnerabilities present in the city based on its geography, demography, history and social and environmental aspects.</p> 
							</div>
							<div class="col-sm-2">
								<img src="assets/images/urban-planing-surat.svg" width="100%"></img>
							</div>
							<div class="col-sm-4">
								<b class="bclr">Surat</b>
								<span class="aic-heading">Sustainable Energy and Climate Action Plan</span>
								<p>Surat has prepared the Sustainable Energy and Climate Action Plan that proposes actions for both climate change mitigation and adaptation based on a GHG emissions inventory and a climate change vulnerability assessment respectively.</p> 
							</div>
						</div>
					</div>
                </div>
				
				<div class="container-fluid">
					<center>
                     <div class="wf-icon"><img src="assets/images/urban-planing-bottom1.svg"></img><h3 class="gclr-wf"> WAY FORWARD </h3></div>
					</center>
					<div class="row1 main-area1">
						<div class="row">
							<div class="col-sm-4">
								<img src="assets/images/urban-planing-bottom2.svg"></img>
							</div>
							<div class="col-sm-4">
								<img src="assets/images/urban-planing-bottom3.svg"></img>
							</div>
							<div class="col-sm-4">
								<img src="assets/images/urban-planing-bottom4.svg"></img>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-4">
								<span class="aic-heading">Establishing dedicated city level committees to strengthen coordination and management across various departments</span>
								<p>Cities can strengthen their institutional coordination and management to ensure holistic planning, implementation and monitoring of climate actions. Specialized committees such as Biodiversity Management Committees, City Climate Cells and Environmental Committees, and City Disaster Management Cells can be established to focus on rejuvenating and safeguarding biodiversity and environment, and guide dedicated activities towards disaster management respectively.</p> 
							</div>
							<div class="col-sm-4">
								<span class="aic-heading">Alignment across various city, state and national plans to ensure coherence in planning and implementation</span>
								<p>In order to adopt rejuvenation and conservation of water bodies and open spaces, enhance biodiversity and drive disaster resilience in cities, local level strategies can be aligned with national and state level plans like the National and State Action Plans for Climate Change (NAPCC and SAPCC), National Clean Air Plan (NCAP), National and State Biodiversity Guidelines (Biological Diversity Act, 2002) and the State/District Disaster Management Plans. Alignment across national and state level plans will bring coherence in the planning and can provide direction to channel required resources for implementation. Besides, streamlining these plans into departmental plans, city master plans and infrastructure DPRs may be ensured for holistic sustainable development in cities.</p> 
							</div>
							<div class="col-sm-4">
								<span class="aic-heading">Data informed decision making</span>
								<p>Spatial mapping and analysis are crucial for assessing gaps and guiding policy making and planning for blue-green planning, biodiversity management and disaster resilience. Cities are recommended to prepare and update GIS maps for attributes like water bodies and open spaces coverage, encroachments, urban heat island, disaster specific risks and vulnerabilities, tree type and biodiversity, etc.</p> 
							</div>
						</div>
						
					</div>
                </div>
				
				<div><button type="button" class="dwn-btn"> Download This Chapter</button></div>
				<div class="container-fluid">
					<div class="row main-area pre-next" >
						<div class="col-sm-6 pre-btn"><a href="cscaf.php">< PREVIOUS</a></div>
						<div class="col-sm-6 nxt-btn"><a href="energy-green-building.php">NEXT ></a></div>
					</div>
                </div>
            </div>
        </div>
        <!-- Bootstrap core JS-->
       <?php include 'include/foot.php'; ?>
    </body>
</html>
