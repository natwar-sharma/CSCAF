﻿
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>CSCAF</title>
        <!-- Favicon-->
		
		<?php include'include/head.php'; ?>
		<!--
		<script src="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"></script>
		-->
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<style>
		/* Scss Document */
		.orange-fade {
			
			/* background: linear-gradient(135deg,#ff910e 0,#ffa841 100%); */
		}
		.pos-r {
			position: relative!important;
		}
		.white {
			background: #fff;
		}
		.text-white {
			color: #fff!important;
		}
		.text-gray {
			color: #363636;
		}
		.testimonial {
			background: #0089CF;
			color: #FFFFFF;
			flex-direction: column;
			justify-content: center;
			align-items: center;
		}
		.separator {
			width: 14%;
			height: 3px;
			margin: 1.2em auto 1em;
			background: #ffc53a;
		}
		.one-slide {
		  border-radius: 3px;
		  margin-left: 1rem;
		  margin-right: 1rem;
		  font-size: 1.1rem;
		  height: 110px;
		}
		.one-slide img {
		  width: 60%;
		}
		.carousel-controls .control {
		  position: absolute;
		  cursor: pointer;
		  top: 56.4%;
		  -webkit-transform: translateY(-50%);
		  -moz-transform: translateY(-50%);
		  -ms-transform: translateY(-50%);
		  -o-transform: translateY(-50%);
		  transform: translateY(-50%);
		  c
		}
		.prev {
		  left: -1.875rem;
		}
		.next {
		  right: -1.875rem;
		}
		.testimonial-carousel { 
		  &.slick-initialized { 
			display: block; 
		  }
		 .message {
			width: 100%;
			font-size: .9rem;
		  }
		  .brand {
			width: 100%;
		  }
		  @media (max-width: 575px) {
			.one-slide {
				height: 200px;
			  }
			img {
				width: 40%;
			  }
		  }
		}
		.testimonial a{
			color: white!important;
			text-decoration: auto !important;
			font-weight: 500;
		}
		.slick-track{
			height: 110px;
		}
		#sidebarToggle{
			display: none;
		}
		</style>
    </head>
    <body>
        <div class="d-flex container" id="wrapper">
            <!-- Sidebar-->
			
			
            <!-- Page content wrapper-->
            <div id="page-content-wrapper" class="hm-contener">
                <!-- Top navigation-->
				
				<?php include'include/header.php'; ?>
                <!-- Page content-->
                <div class="container-fluid1">
					<center>
                    <h1 class="mt-4 bclr"> ClimateSmart Cities Assessment Framework 2.0 </h1>
                    <h1 class="gclr-home"> Cities Readiness Report </h1>
                    <h1 class="gclr-home"> 2021 </h1>
					</center>
					<!--
					<div class="row main-area" >
						<div class="">
							<img src="assets/images/dummy-img.png" width="100%" height="50%"></img>
						</div>
					</div>
					-->
                </div>
				
				<div class="container-fluid1">
					<section class="orange-fade p-5 margin-top-xl pos-r">
					  <div class="container">
						<div class="row">
							<div class="col-sm-12">
						   <div class="mt-5 pos-r">
							  <div class="carousel-controls testimonial-carousel-controls">
								<div class="control prev"><i class="fa fa-chevron-left">&nbsp;</i></div>
								<div class="control next"><i class="fa fa-chevron-right">&nbsp;</i></div>
							  </div>
							  <div class="testimonial-carousel">
								<div class="one-slide white" height="210px !important;">
								  <div class="testimonial w-100 h-100  p-3 text-center">
									<a href="index.php"><div class="message text-center">Introduction</div></a>
								  </div>
								</div>
								<div class="one-slide white">
								  <div class="testimonial w-100 h-100  p-3 text-center">
									<a href="cscaf.php"><div class="message text-center">ClimateSmart Cities Assessment Framework 2.0</div></a>
								  </div>
								</div>
								<div class="one-slide white">
								  <div class="testimonial w-100 h-100  p-3 text-center">
									<a href="urban-planning.php"><div class="message text-center">Urban Planning, Green Cover & Biodiversity</div></a>
								  </div>
								</div>
								<div class="one-slide white">
								  <div class="testimonial w-100 h-100  p-3 text-center">
									<a href="energy-green-building.php"><div class="message text-center">Energy & Green Buildings</div></a>
								  </div>
								</div>
								<div class="one-slide white">
								  <div class="testimonial w-100 h-100  p-3 text-center">
									<a href="mobility-air-quality.php"><div class="message text-center">Mobility & Air Quality</div></a>
								  </div>
								</div>
								<div class="one-slide white">
								  <div class="testimonial w-100 h-100  p-3 text-center">
									<a href="water-management.php"><div class="message text-center">Water Management</div></a>
								  </div>
								</div>
								<div class="one-slide white">
								  <div class="testimonial w-100 h-100  p-3 text-center">
									<a href="waste-management.php"><div class="message text-center">Waste Management</div></a>
								  </div>
								</div>
								<div class="one-slide white">
								  <div class="testimonial w-100 h-100  p-3 text-center">
									<a href="climate-centre-city.php"><div class="message text-center">Climate Centre for Cities</div></a>
								  </div>
								</div>
								
							  </div>
							</div>
						  </div>
						</div>
					  </div>
					</section>
                </div>
				
				<div class="container-fluid1">
					<div class="row main-area" >
						<div class="">
							<img src="assets/images/Logo-Strip.jpg" width="100%"></img>
						</div>
					</div>
                </div>
				
            </div>
        </div>
        
		<!-- Bootstrap core JS-->
		<!-- Bootstrap core JS-->
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
		<!-- Core theme JS-->
		<script src="js/scripts.js"></script>		
		
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" rel="stylesheet">
		<link href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css" rel="stylesheet">
		<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"></script>
			
	</body>
</html>

<script>
	$(document).ready(function() {
    $(".testimonial-carousel").slick({
        infinite: !0,
        slidesToShow: 4,
        slidesToScroll: 1,
        autoplay: !1,
        arrows:true,
        prevArrow: $(".testimonial-carousel-controls .prev"),
        nextArrow: $(".testimonial-carousel-controls .next"),
        responsive: [{
            breakpoint: 1200,
            settings: {
                slidesToShow: 3
            }
        }, {
            breakpoint: 992,
            settings: {
                slidesToShow: 2
            }
        }, {
            breakpoint: 600,
            settings: {
                slidesToShow: 1
            }
        }]
    });
});
</script>
