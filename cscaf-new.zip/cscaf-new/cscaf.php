﻿<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>CSCAF</title>
        <!-- Favicon-->
        <?php include'include/head.php'; ?>
    </head>
    <body>
        <div class="d-flex container" id="wrapper">
            <!-- Sidebar-->
           <?php include'include/sidebar.php'; ?>
            <!-- Page content wrapper-->
            <div id="page-content-wrapper">
                <!-- Top navigation-->
                <?php include'include/header.php'; ?>
                <!-- Page content-->
                <div class="container-fluid">
					<center>
                    <h1 class="mt-4 bclr">2. CSCAF 2.0</h1>
                    <h3 class="gclr"> IMPACT ON CLIMATE ACTION </h3>
					</center>
					<div class="row main-area" >
					
						<div class="row">
							<div class="col-sm-4">
								<img src="assets/images/cscaf-local.svg" class="img-center"></img>
								<div class="col-sm-12">
									<b class="blu-clr">Championing Local Action</b>
									<span>
									<p>First country to do a nationwide climate assessment impacting approx. 140 million people (~1/3rd of urban population) </p>
									</span>
								</div>
							</div>
							
							<div class="col-sm-4">
								<img src="assets/images/cscaf-global.svg" class="img-center"></img>
								<div class="col-sm-12">
									<b class="blu-clr">Demonstrating Global Leadership</b>
									<p>Assessment framework linked with national and international framework and goals </p>
								
								</div>
							</div>
							
							<div class="col-sm-4">
								<img src="assets/images/cscaf-impacts.svg" class="img-center"></img>
								<div class="col-sm-12">
									<b class="blu-clr">Fostering Incremental Impacts</b>
									<p>Development stage indicators to provide guidance for enabling climate actions within ongoing activities </p>
								</div>
							</div>
						</div>
					</div>
                </div>
				
				<div class="container-fluid cscaf-setting">
					<center><h3 class="gclr"> INTRODUCTION TO THEMES  </h3></center>
					<div class="row main-area">
						<div class="row">
							<div class="col-sm-6">
								The CSCAF 2.0 has five themes that capture both mitigation and adaptation aspects of various sectors in a city. The themes have varying weightages in the assessment based on their contribution to GHG emissions. The five themes of CSCAF are:
								<p>1. Urban Planning, Greencover and Biodiversity</p> 
								<p>2. Energy and Green Buildings</p> 
								<p>3. Mobility and Air Quality</p> 
								<p>4. Water Management</p> 
								<p>5. Waste Management</p> 
							</div>
							<div class="col-sm-6">
								<img src="assets/images/cscaf-themes.svg" class="aic-imgmain"></img>
							</div>
						</div>
						
					</div>
                </div>
				<div class="container-fluid cscaf-block2">
					<center><h3 class="gclr"> SUMMARY  </h3></center>
					<div class="row main-area">
						<div class="row">
							<div class="col-sm-6">
								The CSCAF 2.0 assessment indicates that cities have been able to showcase considerable progress since the first assessment conducted in 2019. Significant progress has been reported in the themes of urban planning, green cover and biodiversity; energy and green buildings; and waste management. This year, 54 cities have progressed to the Explorer category by documenting data and initiating assessment studies that can inform developing action plans. Number of cities in the Trendsetter category has increased by 30% and this indicates that cities have established institutional mechanisms for taking up relevant climate actions and have progressed to initiate the preparation of action plans. In comparison to last year, 8 cities are leading by implementing some of the identified climate initiatives. Surat, emerging as the only Climate Champion has also progressed in its climate actions as there were no Champions last year. 
							</div>
							<div class="col-sm-6">
								<img src="assets/images/cscaf-bargraph.svg" width="400px;" ></img>
							</div>
						</div>
						
					</div>
                </div>
				<div class="container-fluid cscaf-block2">
					<center><h3 class="gclr"> PERFORMANCE LABELS </h3></center>
					<div class="row main-area">
						<div class="row">
							<div class="col-sm-6"> 
								<div class="row">
									<div class="col-sm-2 circle-cls" style="background: #32B450;">00</div>
									<div class="col-sm-10"><b class="bclr">FIVE STARS CITIES</b></br>Cities are able to showcase implementation / actions / impacts</div>
								</div>
								<div class="row lbl-setting">
									<div class="col-sm-2 circle-cls" style="background: #93BF5E;">09</div>
									<div class="col-sm-10"><b class="bclr">FOUR STARS CITIES</b></br>Cities have allocated budgets / started implementing climate actions</div>
								</div>
								<div class="row lbl-setting">
									<div class="col-sm-2 circle-cls" style="background: #FFBC31;">22</div>
									<div class="col-sm-10"><b class="bclr">THREE STARS CITIES</b></br>Committees are in place / plans in place / project proposals initiated</div>
								</div>
								<div class="row lbl-setting">
									<div class="col-sm-2 circle-cls" style="background: #F67420;">64</div>
									<div class="col-sm-10"><b class="bclr">TWO STARS CITIES</b></br>Cities collected data/formed committees / hired technical agencies to plan climate action projects</div>
								</div>
								<div class="row lbl-setting">
									<div class="col-sm-2 circle-cls" style="background: #E22C1A;">31</div>
									<div class="col-sm-10"><b class="bclr">ONE STAR CITIES</b></br>Cities have not started thinking / are not in the process of thinking about climate actions</div>
								</div>
							</div>	
							<div class="col-sm-6">
								<img src="assets/images/urban-planing-2a.svg" width="390px;"></img>
								<img src="assets/images/1.png" width="100%"></img>
							</div>
						</div>
						
					</div>
                </div>
				
				<div><button type="button" class="dwn-btn"> Download This Chapter</button></div>
				<div class="container-fluid">
					<div class="row main-area pre-next" >
						<div class="col-sm-6 pre-btn"><a href="index.php">< PREVIOUS</a></div>
						<div class="col-sm-6 nxt-btn"><a href="urban-planning.php">NEXT ></a></div>
					</div>
                </div>
            </div>
        </div>
        <?php include 'include/foot.php'; ?>
    </body>
</html>
